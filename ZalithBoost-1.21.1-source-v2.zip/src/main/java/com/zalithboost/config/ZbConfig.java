package com.zalithboost.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;

public final class ZbConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zalithboost.json");
    public static Data data = new Data();

    public static final class Data {
        public boolean hudEnabled = true, showFps = true, showCoords = true, showCps = true;
        public boolean showSystem = true, showTarget = true, showArmor = true, showEffects = true;
        public boolean showAlerts = true, customCrosshair = false, fpsGraph = true;
        public boolean showArmor = true, showEffects = true, showTarget = true;
        public int enemyRange = 8, lowHealthHearts = 6, durabilityThreshold = 8;
        public int crosshairSize = 6, crosshairThickness = 1, crosshairColor = 0xFFFFFFFF;
        public int crosshairOffsetX = 0, crosshairOffsetY = 0;
        public float hudX = 0.012f, hudY = 0.02f;
        public boolean autoAdjust = false, thermalMode = false;
        public int targetFps = 45, minRenderDistance = 4, maxRenderDistance = 12;
        public int hudColor = 0xFFFFFF, hudOpacity = 180;
        public boolean reduceParticles = false, smoothChunkUpdates = true;
        public int hudRefreshTicks = 5;
    }
    public static void load() {
        try {
            if (Files.exists(FILE)) data = GSON.fromJson(Files.readString(FILE), Data.class);
            if (data == null) data = new Data();
        } catch (Exception e) { data = new Data(); }
    }
    public static void save() {
        try { Files.createDirectories(FILE.getParent()); Files.writeString(FILE, GSON.toJson(data)); }
        catch (Exception e) { System.err.println("[ZalithBoost] No se pudo guardar la configuración: " + e); }
    }
}
