package com.zalithboost.ui;

import com.zalithboost.config.ZbConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Touch/mouse drag editor for the main HUD anchor. */
public final class HudEditorScreen extends Screen {
    private boolean dragging;
    public HudEditorScreen() { super(Text.literal("Editor de HUD")); }
    @Override public boolean mouseClicked(double mouseX,double mouseY,int button) {
        if (button == 0) { dragging = true; moveHud(mouseX,mouseY); return true; }
        return super.mouseClicked(mouseX,mouseY,button);
    }
    @Override public boolean mouseDragged(double mouseX,double mouseY,int button,double deltaX,double deltaY) {
        if (dragging && button == 0) { moveHud(mouseX,mouseY); return true; }
        return super.mouseDragged(mouseX,mouseY,button,deltaX,deltaY);
    }
    @Override public boolean mouseReleased(double mouseX,double mouseY,int button) {
        if (button == 0) { dragging = false; ZbConfig.save(); return true; }
        return super.mouseReleased(mouseX,mouseY,button);
    }
    private void moveHud(double x,double y) {
        ZbConfig.data.hudX = (float)Math.max(0,Math.min(0.95,x/Math.max(1,width)));
        ZbConfig.data.hudY = (float)Math.max(0,Math.min(0.95,y/Math.max(1,height)));
    }
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta) {
        renderBackground(ctx,mouseX,mouseY,delta);
        int x=(int)(width*ZbConfig.data.hudX), y=(int)(height*ZbConfig.data.hudY);
        ctx.drawTextWithShadow(textRenderer,"FPS: 60",x,y,0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer,"XYZ: 0 64 0",x,y+11,0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,"Arrastra el HUD para moverlo",width/2,12,0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,"Pulsa ESC para guardar",width/2,height-18,0xBBBBBB);
    }
    @Override public void close() { ZbConfig.save(); if (client != null) client.setScreen(new SettingsScreen()); }
}
