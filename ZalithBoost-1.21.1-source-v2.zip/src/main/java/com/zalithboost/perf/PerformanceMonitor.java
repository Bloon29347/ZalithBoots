package com.zalithboost.perf;

import com.zalithboost.config.ZbConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Métricas ligeras. No cambia opciones del usuario ni fuerza GC:
 * solo recopila datos para evitar introducir tirones.
 */
public final class PerformanceMonitor {
    private static final AtomicInteger CHUNKS_IN = new AtomicInteger();
    private static final AtomicInteger CHUNKS_OUT = new AtomicInteger();
    private static volatile int lastFps;
    private static volatile int loadedChunks;
    private static int tick;
    private PerformanceMonitor() {}

    public static void init() {
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> CHUNKS_IN.incrementAndGet());
        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> CHUNKS_OUT.incrementAndGet());
    }
    public static void tick(MinecraftClient client) {
        com.zalithboost.perf.CpsTracker.tick(client);
        if (++tick % 20 != 0) return;
        lastFps = client.getCurrentFps();
        ClientWorld world = client.world;
        if (world != null) loadedChunks = world.getChunkManager().getLoadedChunkCount();
    }
    public static int fps() { return lastFps; }
    public static int chunks() { return loadedChunks; }
    public static int chunksLoadedSinceRead() { return CHUNKS_IN.getAndSet(0); }
    public static int chunksUnloadedSinceRead() { return CHUNKS_OUT.getAndSet(0); }
}
