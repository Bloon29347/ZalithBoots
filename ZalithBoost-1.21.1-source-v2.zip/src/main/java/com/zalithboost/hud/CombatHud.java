package com.zalithboost.hud;

import com.zalithboost.config.ZbConfig;
import com.zalithboost.perf.CpsTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

/** Combat readouts are rendered only when enabled in the config. */
public final class CombatHud {
    private CombatHud() {}
    public static void render(DrawContext ctx, MinecraftClient mc) {
        if (mc.player == null) return;
        int color = (ZbConfig.data.hudOpacity << 24) | (ZbConfig.data.hudColor & 0xFFFFFF);
        int y = 6;
        if (ZbConfig.data.showCps) {
            ctx.drawText(mc.textRenderer, "CPS: " + CpsTracker.getCps(), 6, y, color, true);
            y += 11;
        }
        Entity target = mc.crosshairTarget instanceof EntityHitResult hit ? hit.getEntity() : null;
        if (ZbConfig.data.showTarget && target instanceof LivingEntity living && living.isAlive()
                && mc.player.distanceTo(target) <= ZbConfig.data.enemyRange) {
            String name = target.getName().getString();
            String health = String.format(java.util.Locale.ROOT, "%.1f / %.1f HP",
                    living.getHealth(), living.getMaxHealth());
            ctx.drawText(mc.textRenderer, name, 6, y, 0xFFFF5555, true); y += 11;
            ctx.drawText(mc.textRenderer, health, 6, y, color, true); y += 11;
            if (ZbConfig.data.showArmor && target instanceof PlayerEntity player) {
                ctx.drawText(mc.textRenderer, "Armor: " + player.getArmor(), 6, y, color, true); y += 11;
            }
            if (ZbConfig.data.showEffects) {
                for (StatusEffectInstance effect : living.getStatusEffects()) {
                    if (y > 100) break;
                    ctx.drawText(mc.textRenderer, effect.getEffectType().value().getName().getString()
                            + " " + (effect.getAmplifier() + 1), 6, y, color, true);
                    y += 10;
                }
            }
        }
    }
}
