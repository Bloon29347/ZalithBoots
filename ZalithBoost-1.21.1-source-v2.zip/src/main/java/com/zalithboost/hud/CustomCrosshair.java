package com.zalithboost.hud;

import com.zalithboost.config.ZbConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Draws a minimal configurable crosshair over the center of the screen. */
public final class CustomCrosshair {
    private CustomCrosshair() {}
    public static void render(DrawContext ctx, MinecraftClient mc) {
        if (!ZbConfig.data.customCrosshair || mc.options.hudHidden) return;
        int cx = mc.getWindow().getScaledWidth()/2 + ZbConfig.data.crosshairOffsetX;
        int cy = mc.getWindow().getScaledHeight()/2 + ZbConfig.data.crosshairOffsetY;
        int s = ZbConfig.data.crosshairSize, t = Math.max(1, ZbConfig.data.crosshairThickness);
        int c = ZbConfig.data.crosshairColor;
        ctx.fill(cx-s, cy-t/2, cx-2, cy+(t+1)/2, c);
        ctx.fill(cx+2, cy-t/2, cx+s, cy+(t+1)/2, c);
        ctx.fill(cx-t/2, cy-s, cx+(t+1)/2, cy-2, c);
        ctx.fill(cx-t/2, cy+2, cx+(t+1)/2, cy+s, c);
    }
}
