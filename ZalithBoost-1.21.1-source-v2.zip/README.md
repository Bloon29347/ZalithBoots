# ZalithBoost 1.1.0 — reconstrucción para Minecraft 1.21.1

## Qué es este proyecto
Es una reconstrucción basada en la inspección del JAR `zalithboost-1.0.0.jar` aportado en la conversación. El JAR contiene bytecode, recursos e identificadores de las clases originales, pero no los archivos Java originales. Por eso no es posible recuperar literalmente todas las implementaciones ni garantizar que cada detalle visual sea idéntico.

## Entorno
- Minecraft Java 1.21.1
- Fabric Loader 0.16.10+
- Fabric API 0.116.5+1.21.1
- Java 21
- Cliente Android / Zalith Launcher

## Funciones reconstruidas en esta base
- HUD con FPS, coordenadas y conteo de chunks.
- CPS aproximado mediante muestreo del botón izquierdo en ticks.
- Panel del objetivo apuntado: nombre, vida, armadura y efectos.
- Alertas de salud baja y durabilidad de la herramienta.
- Mira personalizada configurable y ocultación de la mira vanilla mediante mixin.
- Menú básico de opciones.
- Editor táctil/ratón para mover el ancla principal del HUD.
- Configuración JSON persistente.
- Contadores de eventos de carga y descarga de chunks.

## Optimizaciones aplicadas
- FPS y cantidad de chunks se actualizan una vez por segundo.
- Coordenadas y textos principales se cachean por tick.
- No se escanean todos los chunks en cada frame.
- No se fuerza `System.gc()` ni se alteran automáticamente opciones gráficas.
- El contador CPS utiliza una muestra ligera por tick; puede no contar clics extremadamente rápidos entre ticks.

## Compilar en GitHub
1. Crea un repositorio y sube el contenido de este ZIP (no subas el ZIP como un único archivo).
2. Abre la pestaña **Actions**.
3. Ejecuta **Build ZalithBoost** con **Run workflow** o haz un commit.
4. Descarga el artefacto `ZalithBoost-Minecraft-1.21.1` cuando termine el workflow.
5. Instala el JAR resultante en el perfil Fabric 1.21.1, junto con Fabric API compatible.

## Límites y pruebas
Esta entrega es una base de reconstrucción ampliada, no una conversión binaria del mod 1.0.0. El editor avanzado original, el botón flotante, los gráficos de FPS, el selector completo de temas, el diagnóstico térmico y algunos elementos de HUD identificados en el bytecode aún no se han replicado completamente. La mejora de carga de chunks aquí es conservadora: mide eventos y evita trabajo repetido del HUD; no reemplaza ni parchea el algoritmo interno de generación/carga de chunks del juego.

No se pudo ejecutar Gradle ni probar el JAR dentro de Minecraft en este entorno. Si GitHub Actions muestra un error de compilación, comparte el log completo para corregir la API exacta que falle. Prueba en una instancia duplicada antes de reemplazar tu mod anterior.
